package com.proyectoSpring.repository;

import org.springframework.data.repository.CrudRepository;
import com.proyectoSpring.model.Ruta;

public interface RutaRepository extends CrudRepository<Ruta, Long>{

}
