package com.proyectoSpring.repository;

import org.springframework.data.repository.CrudRepository;
import com.proyectoSpring.model.Grupo;


public interface GrupoRepository extends CrudRepository<Grupo, Long>{

}
